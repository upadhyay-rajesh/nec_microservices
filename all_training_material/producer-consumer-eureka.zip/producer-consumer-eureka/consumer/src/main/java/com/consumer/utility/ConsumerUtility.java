package com.consumer.utility;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;


public class ConsumerUtility {
	
	@Autowired
	private DiscoveryClient ds;
	
	public void consumeEmployee() {
		
		List<ServiceInstance>  ins=ds.getInstances("EMP-PRODUCER");
		
		ServiceInstance instance=ins.get(0);
		String url=instance.getUri().toString();
		url=url+"/allEmployeeMongo";
		
		RestTemplate rtemp=new RestTemplate();
		ResponseEntity<String> response=null;
		response=rtemp.exchange(url,HttpMethod.GET,getHeader(),String.class);
		System.out.println("comminf from eureka "+response.getBody());
	}
	
	private static HttpEntity<?> getHeader(){
		HttpHeaders h=new HttpHeaders();
		h.set("Accept",MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(h);
	}

}
