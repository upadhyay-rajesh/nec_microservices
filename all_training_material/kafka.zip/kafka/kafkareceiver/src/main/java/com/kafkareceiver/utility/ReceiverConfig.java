package com.kafkareceiver.utility;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;

@Configuration
public class ReceiverConfig {

	@Bean
	public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, String>> kafkalistenerfactory(){
		ConcurrentKafkaListenerContainerFactory<String, String> f=new ConcurrentKafkaListenerContainerFactory<String, String>();
		f.setConsumerFactory(cFactory());
		return f;
	}

	@Bean
	public ConsumerFactory<String, String> cFactory() {
		// TODO Auto-generated method stub
		return new DefaultKafkaConsumerFactory<String, String>(configs());
	}
	
	@Value("${kafka.bootstrapAddress}")
	private String baddress;

	@Bean
	public Map<String, Object> configs() {
		// TODO Auto-generated method stub
		Map<String, Object> p=new HashMap<String, Object>();
		p.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, baddress);
		p.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		p.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		
		p.put(ConsumerConfig.CLIENT_ID_CONFIG, "myid");
		p.put(ConsumerConfig.GROUP_ID_CONFIG, "myid");
		
		return p;
	}

}
