package com.kafkareceiver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.kafkareceiver.utility.Receiver;


@SpringBootApplication
public class KafkareceiverApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkareceiverApplication.class, args);
	}
	
	
	@Bean
	public Receiver cc() {
		return new Receiver();
	}


}
