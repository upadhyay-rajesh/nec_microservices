package com.kafkasender;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkasenderApplicationTests {

	@Test
	void contextLoads() {
	}

}
