package com.kafkasender;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

import com.kafkasender.utility.Sender;

@SpringBootApplication
public class KafkasenderApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx= SpringApplication.run(KafkasenderApplication.class, args);
		Sender ss=ctx.getBean(Sender.class);
		ss.sendMessage("topic1", "hello i am comming from kafka topic");
		System.out.println("message sent successfully");
	}
	
	@Bean
	public Sender cc() {
		return new Sender();
	}

}
