package com.kafkasender.utility;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;

public class Sender {
	
	@Autowired
	KafkaTemplate<String, String> ktemp;
	
	public void sendMessage(String topic,String message) {
		System.out.println("sending message "+message+" to topic "+topic);
		ktemp.send(topic, message);
	}

}
