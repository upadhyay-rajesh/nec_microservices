package com.kafkasender.utility;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

@Configuration
public class SenderConfig {
	
	
	
	@Bean
	public KafkaTemplate<String,String> confTemp(){
		return new KafkaTemplate<String,String>(senderFactory());
	}
	
	@Bean
	public ProducerFactory<String, String> senderFactory() {
		// TODO Auto-generated method stub
		return new DefaultKafkaProducerFactory<String, String>(configs());
	}
	
	@Value("${kafka.bootstrapAddress}")
	private String baddress;

	@Bean
	public Map<String, Object> configs() {
		// TODO Auto-generated method stub
		Map<String, Object> p=new HashMap<String, Object>();
		p.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, baddress);
		p.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		p.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		
		return p;
	}

}




















