package com.producer.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.producer.dao.EmployeeDAOInterface;
import com.producer.dao.EmployeeMongodbInterface;
import com.producer.entity.Employee;

@RestController
public class ProducerController {
	
	

	@RequestMapping("allEmployee")
	public List<Employee> getEmployee(){
		
		List<Employee> l1=new ArrayList<Employee>();
		
		Employee e1=new Employee();
		e1.setName("Rajesh");
		e1.setPassword("abcd");
		e1.setEmail("abc@yahoo.com");
		e1.setAddress("Bangalore");
		
		Employee e2=new Employee();
		e2.setName("Rajesh1");
		e2.setPassword("abcd1");
		e2.setEmail("abc1@yahoo.com");
		e2.setAddress("Bangalore1");
		
		l1.add(e1);
		l1.add(e2);
		return l1;
		
	}
	
	@Autowired
	private EmployeeDAOInterface empdao;
	
	@RequestMapping("allEmployeeJPA")
	public List<Employee> getEmployee1(){
		return empdao.getEmployeeDAO();
	}
	
	
	@Autowired
	private EmployeeMongodbInterface empmongo;
	
	@RequestMapping("allEmployeeMongo")
	public List<Employee> getEmployee2(){
		return empmongo.findAll();
	}
}









