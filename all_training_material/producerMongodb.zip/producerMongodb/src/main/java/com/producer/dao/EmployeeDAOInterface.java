package com.producer.dao;

import java.util.List;

import com.producer.entity.Employee;

public interface EmployeeDAOInterface {

	List<Employee> getEmployeeDAO();

}
