package com.redisproject.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.redisproject.entity.Employee;
import com.redisproject.service.EmployeeService;
@Component
public class EmployeeTask {
	private static final List<String> list=Arrays.asList("Rajesh","Anmol","Manish","Abhinav");
	
	@Autowired
	private EmployeeService empservice;
	
	@Scheduled(fixedDelay = 1000)
	public void retriveEmployee() {
		int index=new Random().nextInt(list.size());
		String empName=list.get(index);
		
		Employee empinfo=empservice.getEmployee(index,empName);
		
		System.out.println("employee is "+empinfo.getEmpName()+"    "+empinfo.getIndex());
		
		
	}
	
	
}
