package com.redisproject.entity;

import java.io.Serializable;

public class Employee implements Serializable{
	
	private int index;
	private String empName;
	
	public Employee() {
		
	}
	public Employee(int index, String empName) {
		this.index=index;
		this.empName=empName;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
	
	
	
	
}
