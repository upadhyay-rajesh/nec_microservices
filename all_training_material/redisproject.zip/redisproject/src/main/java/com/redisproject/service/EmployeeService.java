package com.redisproject.service;

import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.redisproject.entity.Employee;

@Component
@CacheConfig(cacheNames = "EmployeeService")
public class EmployeeService {

	@Cacheable
	public Employee getEmployee(int index, String empName) {
		return new Employee(index,empName);
		
	}

}
