package com.zipkin3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Zipkin3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
