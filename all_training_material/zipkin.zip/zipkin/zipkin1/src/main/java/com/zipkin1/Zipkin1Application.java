package com.zipkin1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Zipkin1Application {

	public static void main(String[] args) {
		SpringApplication.run(Zipkin1Application.class, args);
	}

}
