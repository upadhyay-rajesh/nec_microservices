package com.zipkin1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Zipkin1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
