package com.producer;

import java.util.logging.Logger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProducerApplication {
	
	static Logger log=Logger.getLogger("ProducerApplication");

	public static void main(String[] args) {
		log.info("i am log");
		SpringApplication.run(ProducerApplication.class, args);
	}

}
