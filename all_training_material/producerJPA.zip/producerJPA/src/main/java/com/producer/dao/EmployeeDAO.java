package com.producer.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.producer.entity.Employee;

@Repository
public class EmployeeDAO implements EmployeeDAOInterface{
	
	@Autowired
	private EntityManagerFactory emf;

	@Override
	public List<Employee> getEmployeeDAO(){
		EntityManager em=emf.createEntityManager();
		Query q=em.createQuery("from com.producer.entity.Employee e");
		List<Employee> ll= q.getResultList();
		return ll;
	}
}
